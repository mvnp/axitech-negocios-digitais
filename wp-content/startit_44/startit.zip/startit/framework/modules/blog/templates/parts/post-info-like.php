<div class="qodef-blog-like">
	<?php if( function_exists('qode_startit_get_like') ) qode_startit_get_like(); ?>
</div>