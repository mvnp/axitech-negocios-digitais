<?php

get_header();
get_template_part('title');
get_template_part('slider');
startit_qode_single_portfolio();
get_footer();

?>