<?php

startit_qode_get_footer();

global $qode_startit_toolbar;
if(isset($qode_startit_toolbar)) include("toolbar.php");

?>