<?php

define( 'QODE_CORE_VERSION', '2.2.4' );
define( 'QODE_CORE_ABS_PATH', dirname( __FILE__ ) );
define( 'QODE_CORE_REL_PATH', dirname( plugin_basename( __FILE__ ) ) );
define( 'QODE_CORE_CPT_PATH', QODE_CORE_ABS_PATH . '/post-types' );

define( 'QODE_CORE_URL_PATH', plugin_dir_url( __FILE__ ) );
define( 'QODE_CORE_MODULES_ABS_PATH', QODE_CORE_ABS_PATH . '/modules' );

define( 'QODE_CORE_OPTIONS_NAME', 'qode_options_startit' );
