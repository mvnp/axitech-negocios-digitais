<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/counter/counter.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/counter/custom-styles/counter.php';