<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/pricing-table/pricing-tables.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/pricing-table/pricing-table.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/pricing-table/custom-styles/pricing-table.php';