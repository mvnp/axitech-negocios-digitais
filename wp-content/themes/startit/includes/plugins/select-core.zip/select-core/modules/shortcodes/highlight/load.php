<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/highlight/highlight.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/highlight/custom-styles/highlight.php';