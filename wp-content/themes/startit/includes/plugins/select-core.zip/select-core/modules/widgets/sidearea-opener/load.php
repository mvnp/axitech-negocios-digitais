<?php

require_once QODE_CORE_MODULES_ABS_PATH.'/widgets/sidearea-opener/side-area-opener.php';