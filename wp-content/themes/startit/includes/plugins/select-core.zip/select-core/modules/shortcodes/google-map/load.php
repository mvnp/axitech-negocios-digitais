<?php
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/google-map/google-map.php';

