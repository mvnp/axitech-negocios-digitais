<?php

require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/mobile-showcase/mobile-showcase-holder.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/mobile-showcase/mobile-showcase-item.php';