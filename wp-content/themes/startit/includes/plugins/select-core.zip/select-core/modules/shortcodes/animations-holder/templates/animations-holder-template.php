<div <?php startit_qode_class_attribute($class); ?> <?php echo startit_qode_get_inline_attrs($data); ?>>
	<div <?php startit_qode_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>