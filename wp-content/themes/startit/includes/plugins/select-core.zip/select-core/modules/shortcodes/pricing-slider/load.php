<?php
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/pricing-slider/pricing-slider.php';