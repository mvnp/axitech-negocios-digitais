<?php
if(!class_exists('QodeStartitLike')) {
	include_once QODE_CORE_ABS_PATH . '/modules/like/like.php';
	include_once QODE_CORE_ABS_PATH . '/modules/like/like-functions.php';
}