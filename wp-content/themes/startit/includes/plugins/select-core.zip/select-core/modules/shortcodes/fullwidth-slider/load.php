<?php

require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/fullwidth-slider/fullwidth-slider-holder.php';
require_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/fullwidth-slider/fullwidth-slider-item.php';