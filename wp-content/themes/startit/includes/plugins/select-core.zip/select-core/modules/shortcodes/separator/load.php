<?php

include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/separator/separator.php';
include_once QODE_CORE_MODULES_ABS_PATH.'/shortcodes/separator/custom-styles/separator.php';

