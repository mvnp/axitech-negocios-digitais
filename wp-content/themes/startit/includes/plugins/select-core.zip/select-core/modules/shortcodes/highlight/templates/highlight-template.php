<?php
/**
 * Highlight shortcode template
 */
?>

<span class="qodef-highlight" <?php startit_qode_inline_style($highlight_style);?>>
	<?php echo esc_html($content);?>
</span>