<div class="qodef-social-share-holder qodef-list">
	<ul>
		<?php foreach ($networks as $net) {
			print $net;
		} ?>
	</ul>
</div>