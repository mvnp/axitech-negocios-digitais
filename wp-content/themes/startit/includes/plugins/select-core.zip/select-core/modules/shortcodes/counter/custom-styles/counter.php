<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to qode_startit_style_dynamic hook
 */

//if (!function_exists('qode_startit_counter_style')) {
//
//	function qode_startit_counter_style()
//	{
//
//		if (qode_startit_options()->getOptionValue('option_value') !== '') {
//			echo qode_startit_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => qode_startit_filter_px(qode_startit_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('qode_startit_style_dynamic', 'qode_startit_counter_style');
//
//}

?>